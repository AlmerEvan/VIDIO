import '../App.css';

function Sejarah() {
  return (
    <div className="App">
      <h1>Halaman Sejarah</h1>
      <img src="/images/logo.png" alt="Logo" />
      <p>Ini adalah halaman sejarah yang menjelaskan tentang perjalanan kami</p>
    </div>
  );
}

export default Sejarah;