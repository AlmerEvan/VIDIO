

import '../App.css';

function Kontak() {
  return (
    <div className="App">
      <h1>Halaman Kontak</h1>
      <p>Ini adalah halaman kontak</p>
    </div>
  );
}

export default Kontak;