<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Aplikasi Toko</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
</head>
<body>
    
    <div class="container">
        <div class="mt-5">
            <nav class="navbar navbar-expand-lg bg-light">
                <div class="container-fluid">
                    <a href="/"><img style="width: 100px" src="<?php echo e(asset('gambar/logo.jpg')); ?>" alt=""></a>
                    <ul class="navbar-nav gap-5">
                        <li class="nav-item"><a href="<?php echo e(url('/cart')); ?>">Cart</a></li>
                        <?php if(Session::has('idpelanggan')): ?>
                            <li class="nav-item"><?php echo e(Session::get('email')); ?></li>
                            <li class="nav-item"><a href="<?php echo e(url('logout')); ?>">Log out</a></li>
                        <?php else: ?>
                            <li class="nav-item"><a href="<?php echo e(url('register')); ?>">Register</a></li>
                            <li class="nav-item"><a href="<?php echo e(url('login')); ?>">Log in</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </nav>
        </div>
        <div class="row mt-4">
            <div class="col-2">
                <ul class="list-group">
                    <?php if(isset($kategoris) && $kategoris->count()): ?>
                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item"><a href="<?php echo e(url('show/'.$kategori->idkategori)); ?>"><?php echo e($kategori->kategori); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <li class="list-group-item">No categories available</li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="col-10">
                <?php echo $__env->yieldContent('content'); ?>
            
            </div>
        </div>
        <div>
            footer
        </div>
    </div>

    <script> src="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel-resto-smk\resources\views/front.blade.php ENDPATH**/ ?>