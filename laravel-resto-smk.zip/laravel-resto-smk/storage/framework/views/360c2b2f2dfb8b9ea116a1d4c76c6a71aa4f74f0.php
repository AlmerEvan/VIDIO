<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin LARAVEL Restoran</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.min.css')); ?>">
</head>
<body>
    <div class="container">
        <div class="mt-4">
            <nav class="navbar navbar-expand-lg bg-body-tertiary rounded p-3">
                <div class="container-fluid d-flex justify-content-between align-items-center">
                    <h2>Admin Page</h2>

                    <?php if(Auth::check()): ?>
                        <ul class="navbar-nav flex-row gap-3">
                            <li class="nav-item">
                                <span class="nav-link"><?php echo e(Auth::user()->name); ?></span>
                            </li>
                            <li class="nav-item">
                                <span class="nav-link">Level: <?php echo e(Auth::user()->level); ?></span>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(url('admin/logout')); ?>" class="btn btn-danger btn-sm">
                                    <i class="fa-solid fa-right-from-bracket"></i> Logout
                                </a>
                            </li>
                        </ul>
                    <?php endif; ?>
                </div>
            </nav>
        </div>

        <div class="row mt-4">
            <div class="col-2">
                <ul class="list-group">
                    <?php if(Auth::check() && Auth::user()->level == 'admin'): ?>
                        <li class="list-group-item"><a href="<?php echo e(url('admin/user')); ?>">User</a></li>
                    <?php endif; ?>

                    <?php if(Auth::check() && Auth::user()->level == 'kasir'): ?>
                        <li class="list-group-item"><a href="<?php echo e(url('admin/order')); ?>">Order</a></li>
                        <li class="list-group-item"><a href="<?php echo e(url('admin/orderdetail')); ?>">OrderDetail</a></li>
                    <?php endif; ?>

                    <?php if(Auth::check() && Auth::user()->level == 'manager'): ?>
                        <li class="list-group-item"><a href="<?php echo e(url('admin/pelanggan')); ?>">Pelanggan</a></li>
                        <li class="list-group-item"><a href="<?php echo e(url('admin/kategori')); ?>">Kategori</a></li>
                        <li class="list-group-item"><a href="<?php echo e(url('admin/menu')); ?>">Menu</a></li>
                        <li class="list-group-item"><a href="<?php echo e(url('admin/order')); ?>">Order</a></li>
                        <li class="list-group-item"><a href="<?php echo e(url('admin/orderdetail')); ?>">OrderDetail</a></li>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="col-10">
                <?php echo $__env->yieldContent('admincontent'); ?>
            </div>
        </div>

        <div class="mt-4 text-center">
            <small>© <?php echo e(date('Y')); ?> Laravel Restoran</small>
        </div>
    </div>

    <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-resto-smk\resources\views/Backend/back.blade.php ENDPATH**/ ?>