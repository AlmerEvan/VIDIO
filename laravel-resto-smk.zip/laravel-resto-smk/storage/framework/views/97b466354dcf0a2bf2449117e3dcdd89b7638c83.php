
<?php $__env->startSection('admincontent'); ?>
    <div>
        <h1>User</h1>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-resto-smk\resources\views/Backend/user/select.blade.php ENDPATH**/ ?>