

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php $__currentLoopData = $Menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mx-2 mb-2" style="width: 13rem;">
    
        <img src="<?php echo e(asset('gambar/'.$menu->gambar)); ?>" class="card-img-top img-fluid" alt="..." style="height: 140px; object-fit: cover;">
    
        <div class="card-body">
          <h5 class="card-title"><?php echo e($menu->menu); ?></h5>
          <p class="card-text"><?php echo e($menu->deskripsi); ?></p>
          <p class="card-text"><strong>Rp <?php echo e(number_format($menu->harga, 0, ',', '.')); ?></strong></p>
          <a href="<?php echo e(url('/beli/' . $menu->idmenu)); ?>" class="btn btn-primary w-100">Beli</a>
     </div>
 </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="d-flex justify-content-center mt-4">
        <?php echo e($Menus->onEachSide(1)->links('pagination::simple-bootstrap-4')); ?>

    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-resto-smk\resources\views/kategori.blade.php ENDPATH**/ ?>