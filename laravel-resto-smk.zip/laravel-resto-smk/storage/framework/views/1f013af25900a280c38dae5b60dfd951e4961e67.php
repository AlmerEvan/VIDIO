

<?php $__env->startSection('admincontent'); ?>

<div>
    <h1>Menu</h1>
</div>

<div class="row">
    <div class="col-4">
        <form action="<?php echo e(url('admin/select')); ?>" method="get">
            <select class="form-select" name="idkategori" onchange="this.form.submit()">
                <option value="">-- Pilih Kategori --</option>
                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kategori->idkategori); ?>"
                        <?php echo e(request('idkategori') == $kategori->idkategori ? 'selected' : ''); ?>>
                        <?php echo e($kategori->kategori); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </form>
    </div>
</div>

<div class="mt-2">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Kategori</th>
                <th>Menu</th>
                <th>Deskripsi</th>
                <th>Gambar</th>
                <th>Harga</th>
                <th>Edit</th>
                <th>Hapus</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($menus->firstItem() + $index); ?></td>
                    <td><?php echo e($menu->kategori); ?></td>
                    <td><?php echo e($menu->menu); ?></td>
                    <td><?php echo e($menu->deskripsi); ?></td>
                    <td>
                        <img src="<?php echo e(asset('gambar/' . $menu->gambar)); ?>" alt="<?php echo e($menu->menu); ?>" width="80">
                    </td>
                    <td><?php echo e(number_format($menu->harga, 0, ',', '.')); ?></td>
                    <td>
                        <a href="<?php echo e(url('admin/menu/' . $menu->idmenu . '/edit')); ?>" class="btn btn-warning btn-sm">Edit</a>
                    </td>
                    <td>
                        <form action="<?php echo e(url('admin/menu/' . $menu->idmenu)); ?>" method="POST" onsubmit="return confirm('Yakin hapus data?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($menus->isEmpty()): ?>
                <tr>
                    <td colspan="8" class="text-center">Data menu tidak ditemukan</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <div>
        <?php echo e($menus->withQueryString()->links()); ?>

    </div>

    <div class="mt-3">
        <a href="<?php echo e(url('admin/menu/create')); ?>" class="btn btn-primary">Tambah Data</a>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-resto-smk\resources\views/backend/menu/select.blade.php ENDPATH**/ ?>