
<?php $__env->startSection('admincontent'); ?>
    <div>
        <h1>Kategori</h1>
    </div>
<?php echo $__env->make('Backend.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-resto-smk\resources\views/Backend/kategori/select.blade.php ENDPATH**/ ?>