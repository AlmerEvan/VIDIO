

<?php $__env->startSection('content'); ?>
    <?php if(session('cart')): ?>
        <div class="container-fluid px-0">
            <div class="row mb-4">
                <div class="col-12">
                    <h2 class="fw-bold">Keranjang Belanja</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-8 mb-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Item Pesanan</h5>
                            <a class="btn btn-outline-danger btn-sm" href="<?php echo e(url('batal')); ?>">
                                Kosongkan Keranjang
                            </a>
                        </div>
                        <div class="card-body p-0">
                            <?php
                                $total = 0;
                                $no = 1;
                            ?>

                            <div class="table-responsive">
                                <table class="table mb-0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Menu</th>
                                            <th>Harga</th>
                                            <th>Jumlah</th>
                                            <th>Total</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idmenu => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <?php
                                                            $gambarPath = isset($menu['gambar']) ? 'gambar/'.$menu['gambar'] : 'gambar/default.jpg';
                                                        ?>
                                                        <img src="<?php echo e(asset($gambarPath)); ?>"
                                                             alt="<?php echo e($menu['menu']); ?>"
                                                             class="rounded me-2"
                                                             style="width: 50px; height: 50px; object-fit: cover;">
                                                        <div>
                                                            <h6 class="mb-0"><?php echo e($menu['menu']); ?></h6>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>Rp <?php echo e(number_format($menu['harga'], 0, ',', '.')); ?></td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <a href="<?php echo e(url('kurang/' . $menu['idmenu'])); ?>" class="btn btn-sm btn-outline-secondary me-2">
                                                            -
                                                        </a>
                                                        <span class="mx-2"><?php echo e($menu['jumlah']); ?></span>
                                                        <a href="<?php echo e(url('tambah/' . $menu['idmenu'])); ?>" class="btn btn-sm btn-outline-secondary ms-2">
                                                            +
                                                        </a>
                                                    </div>
                                                </td>
                                                <td>Rp <?php echo e(number_format($menu['jumlah'] * $menu['harga'], 0, ',', '.')); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url('hapus/'.$menu['idmenu'])); ?>" class="btn btn-sm btn-outline-danger">
                                                        Hapus
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php
                                                $total += $menu['jumlah'] * $menu['harga'];
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header">
                            <h5 class="mb-0">Ringkasan Pesanan</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Subtotal</span>
                                <span>Rp <?php echo e(number_format($total, 0, ',', '.')); ?></span>
                            </div>

                            <hr>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Total Pembayaran</span>
                                <span>Rp <?php echo e(number_format($total)); ?></span>
                            </div>

                            <div class="mt-4">
                                <div class="d-grid gap-2">
                                    <a class="btn btn-primary" href="<?php echo e(url('checkout')); ?>">
                                        Checkout Sekarang
                                    </a>
                                    <a class="btn btn-outline" href="<?php echo e(url('menu')); ?>">
                                        Lanjutkan Belanja
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <h3 class="mb-3">Keranjang Belanja Kosong</h3>
            <p class="text-muted mb-4">Anda belum menambahkan menu apapun ke keranjang.</p>
            <a href="<?php echo e(url('menu')); ?>" class="btn btn-primary">
                Lihat Menu
            </a>
        </div>

        <script>
            // Redirect after 3 seconds if cart is empty
            setTimeout(function() {
                window.location.href = '/';
            }, 3000);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-resto-smk\resources\views/cart.blade.php ENDPATH**/ ?>